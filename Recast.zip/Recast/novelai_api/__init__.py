"""
:class:`NovelAI_API`

:class:`NovelAIError`
"""

from novelai_api.NovelAI_API import NovelAIAPI
from novelai_api.NovelAIError import NovelAIError
